# Nodes from 1/16" Grid — Quickstart

- 1 square = 6.25 ft (1"=100').
- Fill SquaresX/Y and Elev_ft; run grid_to_nodes.py to produce Vaquero_Village_nodes.csv

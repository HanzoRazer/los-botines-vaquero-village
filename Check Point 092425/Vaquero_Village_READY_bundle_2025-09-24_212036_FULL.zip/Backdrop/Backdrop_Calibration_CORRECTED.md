# EPANET Backdrop Calibration — Corrected (1/16" grid)

- Grid: **1/16 inch**; Scale: **1"=100'** → **1 square = 6.25 ft**.
- DIMENSIONS: `URx_ft = Nw × 6.25`, `URy_ft = Nh × 6.25`.
- OFFSET: `(mx × 6.25, my × 6.25)` if margins before (0,0).

# Baseline 80CN EPANET Starter

This package contains the files needed to convert the baseline 80-CN network into an EPANET `.inp` file.

## Contents
- `nodes.csv` → All service and connection nodes with attributes (`node_id`, `is_cn`, `east_west_ft`).
- `network_edges.csv` → All pipes with attributes (`from_node`, `to_node`, `length_ft`, `diam_in`, `eps_ft`, `east_west_ft_delta`).
- `csv_to_epanet_inp.py` → Python script to convert the CSVs into an EPANET input file.
- `README.md` → This guide.

## Quick Start

```bash
python csv_to_epanet_inp.py --nodes nodes.csv --edges network_edges.csv --out baseline_80CN_network.inp
```

### Options
- `--psi <value>`: Reservoir head in psi (default 60).
- `--haz`: Use Hazen–Williams instead of Darcy–Weisbach.

## Notes
- Elevations computed as +10 ft per 1000 ft eastward (datum at plant = 0).
- Active CNs get base demand = 1.0 GPM, pattern `PAT100` (PAT125, PAT075, PAT050, PAT0125 also defined).
- Reservoir: `R_PLANT` at 60 psi (≈138.6 ft head).

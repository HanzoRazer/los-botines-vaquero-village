#!/usr/bin/env python3
import pandas as pd
from collections import defaultdict, deque
from pathlib import Path
import argparse

SLOPE = 10.0/1000.0  # +10 ft per 1000 ft eastward

def build_inp(nodes_csv, edges_csv, out_inp, reservoir_head_psi=60.0, use_dw=True):
    nodes = pd.read_csv(nodes_csv)
    edges = pd.read_csv(edges_csv)

    PLANT = "PLANT"
    adj = defaultdict(list)
    for _, r in edges.iterows():
        a, b = r["from_node"], r["to_node"]
        dew = float(r.get("east_west_ft_delta", 0.0))
        adj[a].append((b, dew))
        adj[b].append((a, -dew))

    ew = {row["node_id"]: (0.0 if pd.isna(row["east_west_ft"]) else float(row["east_west_ft"])) for _, row in nodes.iterrows()}
    if PLANT not in ew:
        ew[PLANT] = 0.0

    q = deque([PLANT]); seen = {PLANT}
    while q:
        u = q.popleft()
        for v, dew in adj.get(u, []):
            if v not in ew or ew[v] is None:
                ew[v] = (ew.get(u,0.0) + dew)
            if v not in seen:
                seen.add(v); q.append(v)

    elev = {nid: (0.0 if ew.get(nid) is None else ew[nid]*SLOPE) for nid in ew}

    lines = []
    lines.append("[TITLE]")
    lines.append("; Baseline 80-CN network generated from CSVs")
    lines.append("; UNITS: GPM; Headloss: D-W (roughness = absolute roughness in millifeet).")
    lines.append("")
    lines.append("[JUNCTIONS]")
    lines.append(";ID\tElevation\tDemand\tPattern")
    for _, r in nodes.iterrows():
        nid = r["node_id"]
        if nid == PLANT: continue
        base = 1.0 if (str(nid).startswith("CN") and int(r["is_cn"])==1) else 0.0
        pat = "PAT100" if base>0 else ""
        if pat:
            lines.append(f" {nid}\t{elev.get(nid,0.0):.3f}\t{base:.3f}\t{pat}")
        else:
            lines.append(f" {nid}\t{elev.get(nid,0.0):.3f}\t{base:.3f}")
    lines.append("")
    head_ft = reservoir_head_psi * 2.31
    lines.append("[RESERVOIRS]")
    lines.append(";ID\tHead")
    lines.append(f" R_PLANT\t{head_ft:.2f}")
    lines.append("")
    lines.append("[PIPES]")
    lines.append(";ID\tNode1\tNode2\tLength\tDiameter\tRoughness\tMinorLoss\tStatus")
    for i, r in edges.reset_index().iterrows():
        pid = f"P{i+1}"
        rough_millift = float(r["eps_ft"])*1000.0
        lines.append(f" {pid}\t{r['from_node']}\t{r['to_node']}\t{float(r['length_ft']):.2f}\t{float(r['diam_in']):.3f}\t{rough_millift:.6f}\t0\tOpen")
    lines.append("")
    lines.append("[DEMANDS]")
    lines.append(";Junction\tDemand\tPattern")
    for _, r in nodes.iterrows():
        nid = r["node_id"]
        if nid == PLANT: continue
        if str(nid).startswith("CN") and int(r["is_cn"])==1:
            lines.append(f" {nid}\t1.000\tPAT100")
    lines.append("")
    lines += ["[EMITTERS]","", "[PUMPS]","", "[VALVES]",""]
    lines.append("[PATTERNS]")
    lines.append(";ID\tMultipliers")
    lines.append(" PAT125\t1.25")
    lines.append(" PAT100\t1.00")
    lines.append(" PAT075\t0.75")
    lines.append(" PAT050\t0.50")
    lines.append(" PAT0125\t0.125")
    lines.append("")
    lines += ["[CONTROLS]",""]
    lines.append("[OPTIONS]")
    lines.append(" UNITS               GPM")
    lines.append(f" HEADLOSS            {'D-W' if use_dw else 'H-W'}")
    lines.append(" TRIALS              40")
    lines.append(" ACCURACY            0.001")
    lines.append(" CHECKFREQ           2")
    lines.append(" MAXCHECK            10")
    lines.append(" DAMPLIMIT           0.0")
    lines.append(" SPECGRAV            1.0")
    lines.append(" VISCOSITY           1.0")
    lines.append(" UNBALANCED          STOP 10")
    lines.append(" REPORT              YES")
    lines.append("")
    lines += ["[ENERGY]","", "[STATUS]",""]
    lines.append("[REPORT]")
    lines.append(" PAGESIZE            0")
    lines.append(" STATUS              YES")
    lines.append(" NODES               ALL")
    lines.append(" LINKS               ALL")
    lines.append("")
    lines.append("[COORDINATES]")
    for nid in nodes["node_id"]:
        x = ew.get(nid, 0.0) or 0.0
        lines.append(f" {nid}\t{x:.2f}\t0.00")
    lines.append("")
    lines += ["[TAGS]","", "[VERTICES]","", "[LABELS]","", "[BACKDROP]","", "[MAP]",""]
    Path(out_inp).write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote EPANET file: {out_inp}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nodes", default="nodes.csv")
    ap.add_argument("--edges", default="network_edges.csv")
    ap.add_argument("--out", default="baseline_80CN_network.inp")
    ap.add_argument("--psi", type=float, default=60.0)
    ap.add_argument("--haz", action="store_true")
    a = ap.parse_args()
    build_inp(a.nodes, a.edges, a.out, reservoir_head_psi=a.psi, use_dw=(not a.haz))

if __name__ == "__main__":
    main()

# PLACEHOLDERS — how to mark spots to revisit later

When you reach a CNT/service where special time-varying behavior is needed, mark it so we can fix it later without changing hydraulics today.

## Option A: Tag column (edges)
Set `Tag` to include `NEEDS_RULES` or a specific token you like, e.g.:
- `ZoneB|CNT|NEEDS_RULES`
- `SNT2|CNT|TIME_VAR`

## Option B: Node naming convention (nodes)
Append a suffix in the NodeID for visibility, e.g. `CNT123_NODE__NEEDS_RULES`.
(Safe ASCII; the builders preserve IDs.)

## Later steps (when ready)
- We’ll scan for these tokens and auto-generate:
  - [PATTERNS] with your timestep and multipliers
  - [RULES] for any FCV/pump settings that must change in time
  - Validate in an .INP and deliver one batch update

# EPANET Scripts & Placeholders Bundle
Built: 2025-09-16T06:40:45

This bundle is for later use when you're ready to wire time-varying demand rules.
It does **not** change your edge-building workflow.

Included:
- builders/inp_builder_headers_adapted.py  (uses your exact headers; keeps CNTs)
- builders/csv_to_inp_builder.py           (flexible builder; optional tables)
- tools/topology_guard.py                  (optional; adjacency/evidence; no CSV edits)
- templates/ZoneB_edges_template_HDR.csv, ZoneB_nodes_template_HDR.csv
- templates/ZoneC_edges_template_HDR.csv, ZoneC_nodes_template_HDR.csv
- notes/PLACEHOLDERS.md                    (how to mark locations to revisit later)

You can keep defining edges now; we’ll handle CNT pattern/FCV logic later in one pass.

# VS Code One‑Click Project — 81 CN Water System Simulation (Pinned)

Press **F5** in VS Code to run the full **120‑minute**, **81 active CN** water‑distribution simulation across five demand scenarios.

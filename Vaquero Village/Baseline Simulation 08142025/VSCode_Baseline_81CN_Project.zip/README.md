# VS Code One‑Click Project — Baseline 81 CN (Single‑Pressure Model)

This is the **baseline** simulation rewritten for **81 CNs**. It preserves the same simple global‑pressure logic you used for 80 CNs:
- **Pressure tank drawdown:** 640 gal total (linearized into two bands: 60→38 psi and 38→20 psi)
- **Booster:** single fixed‑flow **20 GPM**, cut‑in at **38 psi**, off above 38 psi
- **No storage/well coupling** (kept off in this baseline to avoid spiky refills)
- **Time step:** 2.5 min, **Horizon:** 120 min
- **Scenarios (GPM/CN):** 1.25, 1.00, 0.75, 0.50, 0.125
- **Active CNs:** 81 (uniform demand per CN)

> This is **not** a hydraulic network solver. It produces a single **system pressure** vs. time based on tank drawdown and a 20 GPM booster.

## Run in VS Code
1. Open this folder in **VS Code**.
2. Press **F5** (Run ▶ *Run Baseline 81 CN*).  
   – or –  
   Open a terminal here and run:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   python run_baseline_81CN.py
   ```

## Outputs
- CSV per scenario at project root: `Scenario_<rate>_GPM_per_CN_81CN.csv`
  - Columns: `Time_min, Pressure_psi, Total_Demand_GPM, Booster_On, Booster_Flow_GPM, Tank_Rem_gal_60to38, Tank_Rem_gal_38to20`
- Chart: `Combined_Pressure_Chart_81CN_Baseline.png`

## Model details
- Phase A (60→38 psi): the pressure tank supplies **total demand**; pressure drops proportionally to the fraction of the **60→38** drawdown used.
- Phase B (≤38 psi): the booster provides **20 GPM**; the tank supplies only the **deficit** (`total_demand − 20`); pressure drops proportionally to the fraction of the **38→20** drawdown used.
- Simulation ends at **20 psi** (failure) or **120 min**.
